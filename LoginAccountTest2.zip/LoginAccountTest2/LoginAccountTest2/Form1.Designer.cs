﻿namespace LoginAccount
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelLogin = new System.Windows.Forms.Label();
            this.linkLabelCreateNew = new System.Windows.Forms.LinkLabel();
            this.buttonLogin = new System.Windows.Forms.Button();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.textPW = new System.Windows.Forms.TextBox();
            this.labelPW = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.Font = new System.Drawing.Font("Microsoft YaHei UI", 13F);
            this.labelLogin.Location = new System.Drawing.Point(99, 69);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(85, 35);
            this.labelLogin.TabIndex = 0;
            this.labelLogin.Text = "Login";
            this.labelLogin.Click += new System.EventHandler(this.labelLogin_Click);
            // 
            // linkLabelCreateNew
            // 
            this.linkLabelCreateNew.AutoSize = true;
            this.linkLabelCreateNew.Location = new System.Drawing.Point(100, 203);
            this.linkLabelCreateNew.Name = "linkLabelCreateNew";
            this.linkLabelCreateNew.Size = new System.Drawing.Size(120, 20);
            this.linkLabelCreateNew.TabIndex = 5;
            this.linkLabelCreateNew.TabStop = true;
            this.linkLabelCreateNew.Text = "Create Account";
            this.linkLabelCreateNew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCreateNew_LinkClicked);
            // 
            // buttonLogin
            // 
            this.buttonLogin.Location = new System.Drawing.Point(264, 195);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(92, 35);
            this.buttonLogin.TabIndex = 6;
            this.buttonLogin.Text = "Login";
            this.buttonLogin.UseVisualStyleBackColor = true;
            this.buttonLogin.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(196, 118);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(158, 26);
            this.textEmail.TabIndex = 3;
            this.textEmail.Leave += new System.EventHandler(this.textEmail_Leave);
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(100, 118);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(48, 20);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email";
            this.labelEmail.Click += new System.EventHandler(this.labelEmail_Click);
            // 
            // textPW
            // 
            this.textPW.Location = new System.Drawing.Point(196, 151);
            this.textPW.Name = "textPW";
            this.textPW.Size = new System.Drawing.Size(158, 26);
            this.textPW.TabIndex = 4;
            this.textPW.UseSystemPasswordChar = true;
            this.textPW.TextChanged += new System.EventHandler(this.textPW_TextChanged);
            // 
            // labelPW
            // 
            this.labelPW.AutoSize = true;
            this.labelPW.Location = new System.Drawing.Point(100, 149);
            this.labelPW.Name = "labelPW";
            this.labelPW.Size = new System.Drawing.Size(78, 20);
            this.labelPW.TabIndex = 0;
            this.labelPW.Text = "Password";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 335);
            this.Controls.Add(this.textPW);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.buttonLogin);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.linkLabelCreateNew);
            this.Controls.Add(this.labelPW);
            this.Controls.Add(this.labelLogin);
            this.Name = "LoginForm";
            this.Text = "Login Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.LinkLabel linkLabelCreateNew;
        private System.Windows.Forms.Button buttonLogin;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox textPW;
        private System.Windows.Forms.Label labelPW;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

