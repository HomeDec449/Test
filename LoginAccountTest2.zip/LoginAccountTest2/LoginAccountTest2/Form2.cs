﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace LoginAccount
{
    public partial class CreateAccountForm : Form
    {
        string connectionString = @"Data Source=sqlserver449.database.windows.net;Initial Catalog=HomeDec;User ID=laurrennicolee;Password=Falltime2!;Connect Timeout=60;Encrypt=True;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public CreateAccountForm()
        {
            InitializeComponent();
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if (textEmailReg.Text == "" || textPWReg.Text == "")
                MessageBox.Show("Please fill empty fields");
            else if (textPWReg.Text != textPWReg2.Text)
                MessageBox.Show("Passwords do not match.");
            else
            {

                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("UserAdd", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@FirstName", textFirstName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@LastName", textLastName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Email", textEmailReg.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Passwords", textPWReg.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Account Created");
                    this.Hide();
                    LoginForm f1 = new LoginForm();
                    f1.ShowDialog();
                    // stop hidden form from running in background
                    this.Close();
                    Clear();
                }
            }
            void Clear()
            {
                textFirstName.Text = textLastName.Text = textEmailReg.Text = textPWReg.Text = textPWReg2.Text;
            }
        }

        private void richTextPolicy_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textEmailReg_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(textEmailReg.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.textEmailReg, "Invalid email address. Please try again.");
            }
        }

        private void linkLabelSignin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            LoginForm f1 = new LoginForm();
            f1.ShowDialog();
            // stop hidden form from running in background
            this.Close();
        }
    }
 
}

