﻿namespace LoginAccount
{
    partial class CreateAccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelCreateAcct = new System.Windows.Forms.Label();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.textFirstName = new System.Windows.Forms.TextBox();
            this.labelLastName = new System.Windows.Forms.Label();
            this.textLastName = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.textEmailReg = new System.Windows.Forms.TextBox();
            this.labelPW = new System.Windows.Forms.Label();
            this.textPWReg = new System.Windows.Forms.TextBox();
            this.labelPW2 = new System.Windows.Forms.Label();
            this.textPWReg2 = new System.Windows.Forms.TextBox();
            this.buttonCreate = new System.Windows.Forms.Button();
            this.labelAlready = new System.Windows.Forms.Label();
            this.linkLabelSignin = new System.Windows.Forms.LinkLabel();
            this.richTextPolicy = new System.Windows.Forms.RichTextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCreateAcct
            // 
            this.labelCreateAcct.AutoSize = true;
            this.labelCreateAcct.Font = new System.Drawing.Font("Microsoft YaHei UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCreateAcct.Location = new System.Drawing.Point(40, 58);
            this.labelCreateAcct.Name = "labelCreateAcct";
            this.labelCreateAcct.Size = new System.Drawing.Size(207, 35);
            this.labelCreateAcct.TabIndex = 0;
            this.labelCreateAcct.Text = "Create Account";
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFirstName.Location = new System.Drawing.Point(85, 111);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(96, 20);
            this.labelFirstName.TabIndex = 0;
            this.labelFirstName.Text = "First Name";
            // 
            // textFirstName
            // 
            this.textFirstName.Location = new System.Drawing.Point(89, 134);
            this.textFirstName.Name = "textFirstName";
            this.textFirstName.Size = new System.Drawing.Size(211, 26);
            this.textFirstName.TabIndex = 1;
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLastName.Location = new System.Drawing.Point(86, 163);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(95, 20);
            this.labelLastName.TabIndex = 0;
            this.labelLastName.Text = "Last Name";
            // 
            // textLastName
            // 
            this.textLastName.Location = new System.Drawing.Point(90, 186);
            this.textLastName.Name = "textLastName";
            this.textLastName.Size = new System.Drawing.Size(211, 26);
            this.textLastName.TabIndex = 2;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(86, 215);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(53, 20);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email";
            // 
            // textEmailReg
            // 
            this.textEmailReg.Location = new System.Drawing.Point(89, 242);
            this.textEmailReg.Name = "textEmailReg";
            this.textEmailReg.Size = new System.Drawing.Size(211, 26);
            this.textEmailReg.TabIndex = 3;
            this.textEmailReg.Leave += new System.EventHandler(this.textEmailReg_Leave);
            // 
            // labelPW
            // 
            this.labelPW.AutoSize = true;
            this.labelPW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPW.Location = new System.Drawing.Point(86, 271);
            this.labelPW.Name = "labelPW";
            this.labelPW.Size = new System.Drawing.Size(86, 20);
            this.labelPW.TabIndex = 0;
            this.labelPW.Text = "Password";
            // 
            // textPWReg
            // 
            this.textPWReg.Location = new System.Drawing.Point(90, 294);
            this.textPWReg.Name = "textPWReg";
            this.textPWReg.Size = new System.Drawing.Size(211, 26);
            this.textPWReg.TabIndex = 4;
            this.textPWReg.UseSystemPasswordChar = true;
            // 
            // labelPW2
            // 
            this.labelPW2.AutoSize = true;
            this.labelPW2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPW2.Location = new System.Drawing.Point(85, 323);
            this.labelPW2.Name = "labelPW2";
            this.labelPW2.Size = new System.Drawing.Size(162, 20);
            this.labelPW2.TabIndex = 0;
            this.labelPW2.Text = "Re-enter Password";
            // 
            // textPWReg2
            // 
            this.textPWReg2.Location = new System.Drawing.Point(89, 346);
            this.textPWReg2.Name = "textPWReg2";
            this.textPWReg2.Size = new System.Drawing.Size(211, 26);
            this.textPWReg2.TabIndex = 5;
            this.textPWReg2.UseSystemPasswordChar = true;
            // 
            // buttonCreate
            // 
            this.buttonCreate.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonCreate.Location = new System.Drawing.Point(75, 392);
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.Size = new System.Drawing.Size(261, 30);
            this.buttonCreate.TabIndex = 6;
            this.buttonCreate.Text = "Create HomeDec Account";
            this.buttonCreate.UseVisualStyleBackColor = false;
            this.buttonCreate.Click += new System.EventHandler(this.buttonCreate_Click);
            // 
            // labelAlready
            // 
            this.labelAlready.AutoSize = true;
            this.labelAlready.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAlready.Location = new System.Drawing.Point(74, 481);
            this.labelAlready.Name = "labelAlready";
            this.labelAlready.Size = new System.Drawing.Size(173, 17);
            this.labelAlready.TabIndex = 0;
            this.labelAlready.Text = "Already have an account?";
            // 
            // linkLabelSignin
            // 
            this.linkLabelSignin.AutoSize = true;
            this.linkLabelSignin.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelSignin.Location = new System.Drawing.Point(270, 481);
            this.linkLabelSignin.Name = "linkLabelSignin";
            this.linkLabelSignin.Size = new System.Drawing.Size(51, 17);
            this.linkLabelSignin.TabIndex = 7;
            this.linkLabelSignin.TabStop = true;
            this.linkLabelSignin.Text = "Sign in";
            this.linkLabelSignin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelSignin_LinkClicked);
            // 
            // richTextPolicy
            // 
            this.richTextPolicy.BackColor = System.Drawing.SystemColors.Control;
            this.richTextPolicy.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextPolicy.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextPolicy.Location = new System.Drawing.Point(75, 428);
            this.richTextPolicy.Name = "richTextPolicy";
            this.richTextPolicy.ReadOnly = true;
            this.richTextPolicy.Size = new System.Drawing.Size(278, 40);
            this.richTextPolicy.TabIndex = 0;
            this.richTextPolicy.Text = "By creating an account, you agree to HomeDec’s Conditions of Use and Privacy Noti" +
    "ce.";
            this.richTextPolicy.TextChanged += new System.EventHandler(this.richTextPolicy_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // CreateAccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 581);
            this.Controls.Add(this.richTextPolicy);
            this.Controls.Add(this.linkLabelSignin);
            this.Controls.Add(this.labelAlready);
            this.Controls.Add(this.buttonCreate);
            this.Controls.Add(this.textPWReg2);
            this.Controls.Add(this.textPWReg);
            this.Controls.Add(this.textEmailReg);
            this.Controls.Add(this.textLastName);
            this.Controls.Add(this.textFirstName);
            this.Controls.Add(this.labelPW2);
            this.Controls.Add(this.labelPW);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelLastName);
            this.Controls.Add(this.labelFirstName);
            this.Controls.Add(this.labelCreateAcct);
            this.Name = "CreateAccountForm";
            this.Text = "Create Account";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCreateAcct;
        private System.Windows.Forms.Label labelFirstName;
        private System.Windows.Forms.TextBox textFirstName;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.TextBox textLastName;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox textEmailReg;
        private System.Windows.Forms.Label labelPW;
        private System.Windows.Forms.TextBox textPWReg;
        private System.Windows.Forms.Label labelPW2;
        private System.Windows.Forms.TextBox textPWReg2;
        private System.Windows.Forms.Button buttonCreate;
        private System.Windows.Forms.Label labelAlready;
        private System.Windows.Forms.LinkLabel linkLabelSignin;
        private System.Windows.Forms.RichTextBox richTextPolicy;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}