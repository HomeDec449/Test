﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
//For Database Connection
using System.Data.SqlClient;


//Webpage is displayed
// User account icon is clicked
// Login Form



namespace LoginAccount
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void labelLogin_Click(object sender, EventArgs e)
        {

        }

        private void labelEmail_Click(object sender, EventArgs e)
        {

        }

        private void textEmail_TextChanged(object sender, EventArgs e)
        {


        }

        private void textPW_TextChanged(object sender, EventArgs e)
        {

        }
        // Create New Account form 
        private void linkLabelCreateNew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            this.Hide();
            CreateAccountForm f2 = new CreateAccountForm();
            f2.ShowDialog();
            // stop hidden form from running in background
            this.Close();

        }
        //Login 
        private void buttonLogin_Click(object sender, EventArgs e)
        {

            // Verify account in SQL database
            // For SQL connection
            SqlConnection con = new SqlConnection(@"Data Source=sqlserver449.database.windows.net;Initial Catalog=HomeDec;User ID=laurrennicolee;Password=Falltime2!;Connect Timeout=60;Encrypt=True;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            //in (""); Visual studio > enter database connection, look for DB properties, c&p connection string into ("")
            SqlDataAdapter sda = new SqlDataAdapter("Select count(*) from CustomerAccount where Email='" + textEmail.Text + "' and Passwords='" + textPW.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {

                this.Hide();
                MessageBox.Show("Login Successful.");
                // Main ss = new Main(); 
                //ss.Show();

            }

            else
            {
                MessageBox.Show("Email and/or password is invalid. Please try again.");
            }
        }

        private void textEmail_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(textEmail.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.textEmail, "Please provide a valid email address");
            }
        }
    }

}
